import { TestBed } from '@angular/core/testing';

import { AuthTraveldeskexecService } from './auth-traveldeskexec.service';

describe('AuthTraveldeskexecService', () => {
  let service: AuthTraveldeskexecService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthTraveldeskexecService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
