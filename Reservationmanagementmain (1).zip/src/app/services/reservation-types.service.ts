import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReservationTypes } from '../models/reservationTypes';

@Injectable({
  providedIn: 'root'
})
export class ReservationTypesService {

  constructor(private http: HttpClient) {
  }
  private fetchReservationTypesURL = 'http://localhost:8091/api/reservations/types';

  public getAllReservationTypes() {
    return this.http.get<ReservationTypes[]>(this.fetchReservationTypesURL);
  }
}
