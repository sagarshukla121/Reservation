import { TestBed } from '@angular/core/testing';

import { ReservationDocsService } from './reservation-docs.service';

describe('ReservationDocsService', () => {
  let service: ReservationDocsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReservationDocsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
