import { Component } from '@angular/core';
import { Reservations } from '../models/reservations';
import { OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReservationsService } from '../services/reservations.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-track-reservation',
  templateUrl: './track-reservation.component.html',
  styleUrl: './track-reservation.component.css'
})
export class TrackReservationComponent implements OnInit {
  reservations!: Reservations[];
  searchForm!: FormGroup;


  constructor(private router: Router, private reservationsService: ReservationsService) { }

  ngOnInit() {
    this.searchForm = new FormGroup({
      'travelRequestId': new FormControl(null, [Validators.required, Validators.min(0)])
    });
    this.searchForm.get?.('travelRequestId')?.valueChanges.subscribe(value => {
      if (!value) {
        this.reservations = [];
      }
    });
  }
  onSearch() {
    const travelRequestId = this.searchForm.get('travelRequestId')?.value;
    this.reservationsService.getAllTravelReservationsRequest(travelRequestId).subscribe({
      next: (reservations: Reservations[]) => {
        this.reservations = reservations;
        console.log(reservations);
      },
      error: err => {
        this.reservations = [];
        let notificationBar = document.getElementById('notification-bar');
        if (notificationBar !== null) {
          let errorMessage = err.error;
          notificationBar.innerHTML = `<div class="alert alert-danger" role="alert">${errorMessage}</div>`;
          setTimeout(() => {
            if (notificationBar !== null) {
              notificationBar.innerHTML = '';
            }
          }, 5000);
        }
      }
    });
  }
  viewDetails(id: number) {
    this.router.navigate(['/reservation-details', id]);
  }
  clearForm() {
    this.searchForm.reset();
  }
  displayError(controlName: string, errorName: string) {
    const control = this.searchForm.get(controlName);
    return control && (control.touched || control.dirty) && control.hasError(errorName);
  }
}
