export interface ReservationTypes {
    typeId: number;
    typeName: String;
}