import { Component, OnInit } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { ReservationTypes } from '../models/reservationTypes';
import { ReservationTypesService } from '../services/reservation-types.service';
import { ReservationsService } from '../services/reservations.service';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-upload-reservation',
  templateUrl: './upload-reservation.component.html',
  styleUrl: './upload-reservation.component.css'
})
export class UploadReservationComponent implements OnInit {

  reservationTypes: ReservationTypes[] = [];
  newReservationForm!: FormGroup;
  addForm!: FormGroup;
  files!: File[];
  urls: string[] = [];
  today = '';
  filesizeError: string = "";

  //For handling File Sizea and filetype
  handleFileInput(event: any) {
    this.filesizeError = ''; // Reset the error message
    if (event.target.files && event.target.files.length > 0) {
      this.files = Array.from(event.target.files);
      for (let file of this.files) {
        let fileSizeInMB = file.size / (1024 * 1024);
        console.log(fileSizeInMB)
        let fileType = file.type;
        if (fileType !== "application/pdf") {
          this.filesizeError = 'Only PDF files are allowed';
          break;
        }
        if (fileSizeInMB > 1) {
          this.filesizeError = 'File size must be less than 1MB';
          console.log(this.filesizeError)
          break;
        }
      }
    }
    console.log(this.files);
  }

  constructor(private fireStorage: AngularFireStorage, private reservationTypesService: ReservationTypesService, private reservationsService: ReservationsService) {
    this.today = formatDate(new Date(), 'yyyy-MM-dd', 'en-US');
  }
  ngOnInit() {
    this.fetchReservationEntities();

    //validations on the input field
    this.newReservationForm = new FormGroup({
      'reservationDoneByEmployeeId': new FormControl(null, [Validators.required, Validators.pattern(/^\d{7}$/), Validators.min(0)]),
      'travelRequestId': new FormControl(null, [Validators.required, Validators.min(0)]),
      'reservationDoneWithEntity': new FormControl(null, Validators.required),
      'reservationDate': new FormControl(null, Validators.required),
      'amount': new FormControl(null, [Validators.required, this.positiveNumber, Validators.min(700), Validators.max(21000)]),
      'confirmationID': new FormControl(null, [Validators.required, Validators.min(0), Validators.max(9999999999)]),
      'remarks': new FormControl(null, Validators.required),
      'documentURLS': new FormControl([], Validators.required),
      'fromDate': new FormControl(null, Validators.required)
    });
  }


  async onSubmit() {
    console.log(this.newReservationForm)

    //uploading file in fire base 
    for (let i = 0; i < this.files.length; i++) {
      const file = this.files[i];
      const filePath = `${file.name}`;
      const uploadTask = await this.fireStorage.upload(filePath, file);
      const url = await uploadTask.ref.getDownloadURL();
      this.urls.push(url);
    }

    //adding the data in the form controls field
    this.addForm = new FormGroup({
      'reservationDoneByEmployeeId': new FormControl(this.newReservationForm.get('reservationDoneByEmployeeId')?.value),
      'travelRequestId': new FormControl(this.newReservationForm.get('travelRequestId')?.value),
      'reservationDoneWithEntity': new FormControl(this.newReservationForm.get('reservationDoneWithEntity')?.value),
      'reservationDate': new FormControl(this.newReservationForm.get('reservationDate')?.value),
      'amount': new FormControl(this.newReservationForm.get('amount')?.value),
      'confirmationID': new FormControl(this.newReservationForm.get('confirmationID')?.value),
      'remarks': new FormControl(this.newReservationForm.get('remarks')?.value),
      'documentURLS': new FormControl(this.urls),
      'fromDate': new FormControl(this.newReservationForm.get('fromDate')?.value)
    });

    //making it empty for next time use
    this.urls = [];


    console.log(this.addForm.value);

    //sending my form data to the service
    this.reservationsService.addNewReservationsRequest(this.addForm.value).subscribe({
      next: responseData => {
        console.log(responseData);
        let notificationBar = document.getElementById('notification-bar');
        if (notificationBar !== null) {
          notificationBar.innerHTML = `<div class="alert alert-success" role="alert">${responseData}</div>`;
          setTimeout(() => {
            if (notificationBar !== null) {
              notificationBar.innerHTML = '';
            }
          }, 5000);
        }
      },
      error: err => { //for showing errr if occurs
        console.log(err)
        let notificationBar = document.getElementById('notification-bar');
        if (notificationBar !== null) {
          let errorMessage = err.error;
          notificationBar.innerHTML = `<div class="alert alert-danger" role="alert">${errorMessage}</div>`;
          setTimeout(() => {
            if (notificationBar !== null) {
              notificationBar.innerHTML = '';
            }
          }, 5000);
        }
      }
    });

    this.newReservationForm.reset();
    this.addForm.reset();
    this.scrollToTop();

  }

  validateEmployeeIdLength(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const employeeId = control.value;
      console.log(employeeId)
      const minLength = 7;
      const maxLength = 7;

      if (employeeId.length < minLength || employeeId.length > maxLength) {
        return {
          invalidLength: true
        };
      }
      return null;
    }
  }

  fetchReservationEntities() {
    this.reservationTypesService.getAllReservationTypes()
      .subscribe(responseData => {
        this.reservationTypes = responseData;
      })
  }
  scrollToTop() {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }
  displayError(controlName: string, errorName: string) {
    const control = this.newReservationForm.get(controlName);
    return control && (control.touched || control.dirty) && control.hasError(errorName);
  }

  positiveNumber(control: AbstractControl) {
    return (control.value > 0) ? null : { 'negative': true };
  }

}
