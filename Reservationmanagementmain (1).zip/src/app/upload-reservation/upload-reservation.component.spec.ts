import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadReservationComponent } from './upload-reservation.component';

describe('UploadReservationComponent', () => {
  let component: UploadReservationComponent;
  let fixture: ComponentFixture<UploadReservationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UploadReservationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UploadReservationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
