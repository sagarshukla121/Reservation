import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UploadReservationComponent } from './upload-reservation/upload-reservation.component';
import { TrackReservationComponent } from './track-reservation/track-reservation.component';
import { ReservationDetailsComponent } from './reservation-details/reservation-details.component';
import { LoginComponent } from './login/login.component';
import { AuthTraveldeskexecService } from './services/auth-traveldeskexec.service';
import { AuthEmployeeService } from './services/auth-employee.service';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  { path: 'upload', component: UploadReservationComponent, canActivate: [AuthTraveldeskexecService] },
  { path: 'track', component: TrackReservationComponent, canActivate: [AuthEmployeeService] },
  { path: 'reservation-details/:id', component: ReservationDetailsComponent, canActivate: [AuthEmployeeService] },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: '**', redirectTo: '/login', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
