export const environment = {
    production: false,
    firebase: {
        apiKey: 'AIzaSyCij377R3UqA5-RKUmqTWDN65-v9dyrAvc',
        authDomain: 'reservations-management-2e971.firebaseapp.com',
        databaseURL: 'https://reservations-management-2e971-default-rtdb.firebaseio.com/',
        projectId: 'reservations-management-2e971',
        storageBucket: "reservations-management-2e971.appspot.com",
        messagingSenderId: "519938449285",
        appId: "1:519938449285:web:648c9ef3075728a6a76eec"
    }
};
