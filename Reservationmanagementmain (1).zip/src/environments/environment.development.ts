export const environment = {
    production: false,
    firebase: {
        apiKey: 'AIzaSyCMTeMb9s8daCLbH0tCo0QwRjSX7lA2g-c',
        authDomain: 'reservationdocuments-fdc4c.firebaseapp.com',
        databaseURL: 'https://reservationdocuments-fdc4c-default-rtdb.firebaseio.com',
        projectId: 'reservationdocuments-fdc4c',
        storageBucket: 'reservationdocuments-fdc4c.appspot.com',
        messagingSenderId: '421467484279',
        appId: '1:421467484279:web:b6d66f7f11220fb419d672',
        measurementId: 'G-YJ2DTR5SE5'
    }
};
